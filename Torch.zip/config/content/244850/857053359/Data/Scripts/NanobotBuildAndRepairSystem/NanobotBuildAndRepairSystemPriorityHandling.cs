namespace SpaceEquipmentLtd.NanobotBuildAndRepairSystem
{
   using Utils;
   using VRage.Game;
   using VRage.Game.ModAPI;

   public enum BlockClass
   {
      AutoRepairSystem = 1,
      ShipController,
      Thruster,
      Gyroscope,
      CargoContainer,
      Conveyor,
      ControllableGun,
      PowerBlock,
      ProgrammableBlock,
      Projector,
      FunctionalBlock,
      ProductionBlock,
      Door,
      ArmorBlock
   }

   public enum ComponentClass
   {
      Material = 1,
      Ingot,
      Ore,
      Stone,
      Gravel
   }

   public class NanobotBuildAndRepairSystemBlockPriorityHandling : PriorityHandling<BlockClass, IMySlimBlock>
   {
      /// <summary>
      /// Get the Block class
      /// </summary>
      /// <param name="a"></param>
      /// <returns></returns>
      public override BlockClass GetItemClass(IMySlimBlock a, bool real)
      {
         var block = a.FatBlock;
         if (block == null) return BlockClass.ArmorBlock;
         var functionalBlock = block as Sandbox.ModAPI.IMyFunctionalBlock;
         if (!real && functionalBlock != null && !functionalBlock.Enabled) return BlockClass.ArmorBlock; //Switched off -> handle as structural block (if logical class is asked)

         if (block is Sandbox.ModAPI.IMyShipWelder && block.BlockDefinition.SubtypeName.Contains("NanobotBuildAndRepairSystem")) return BlockClass.AutoRepairSystem;
         if (block is Sandbox.ModAPI.IMyShipController) return BlockClass.ShipController;
         if (block is Sandbox.ModAPI.IMyThrust || block is Sandbox.ModAPI.IMyWheel || block is Sandbox.ModAPI.IMyMotorRotor) return BlockClass.Thruster;
         if (block is Sandbox.ModAPI.IMyGyro) return BlockClass.Gyroscope;
         if (block is Sandbox.ModAPI.IMyCargoContainer) return BlockClass.CargoContainer;
         if (block is Sandbox.ModAPI.IMyConveyor || a.FatBlock is Sandbox.ModAPI.IMyConveyorSorter || a.FatBlock is Sandbox.ModAPI.IMyConveyorTube) return BlockClass.Conveyor;
         if (block is Sandbox.ModAPI.IMyUserControllableGun) return BlockClass.ControllableGun;
         if (block is Sandbox.ModAPI.IMyWarhead) return BlockClass.ControllableGun;
         if (block is Sandbox.ModAPI.IMyPowerProducer) return BlockClass.PowerBlock;
         if (block is Sandbox.ModAPI.IMyProgrammableBlock) return BlockClass.ProgrammableBlock;
         if (block is SpaceEngineers.Game.ModAPI.IMyTimerBlock) return BlockClass.ProgrammableBlock;
         if (block is Sandbox.ModAPI.IMyProjector) return BlockClass.Projector;
         if (block is Sandbox.ModAPI.IMyDoor) return BlockClass.Door;
         if (block is Sandbox.ModAPI.IMyProductionBlock) return BlockClass.ProductionBlock;
         if (functionalBlock != null) return BlockClass.FunctionalBlock;

         return BlockClass.ArmorBlock;
      }
   }

   public class NanobotBuildAndRepairSystemComponentPriorityHandling : PriorityHandling<ComponentClass, MyDefinitionId>
   {
      /// <summary>
      /// Get the Block class
      /// </summary>
      /// <param name="a"></param>
      /// <returns></returns>
      public override ComponentClass GetItemClass(MyDefinitionId a, bool real)
      {
         if (a.TypeId == typeof(MyObjectBuilder_Ingot))
         {
            if (a.SubtypeName == "Stone") return ComponentClass.Gravel;
            return ComponentClass.Ingot;
         }
         if (a.TypeId == typeof(MyObjectBuilder_Ore))
         {
            if (a.SubtypeName == "Stone") return ComponentClass.Stone;
            return ComponentClass.Ore;
         }
         return ComponentClass.Material;
      }
   }
}
