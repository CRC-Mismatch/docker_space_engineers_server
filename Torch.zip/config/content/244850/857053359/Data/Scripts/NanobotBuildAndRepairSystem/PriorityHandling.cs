using System;
using System.Collections.Generic;
using System.Linq;
using VRage.ModAPI;
using VRage.Utils;

namespace SpaceEquipmentLtd.Utils
{
   public class ClassState<T> where T : struct
   {
      public T ItemClass { get; }
      public bool Enabled { get; set; }
      public bool Visible { get; set; }
      public ClassState(T itemClass, bool enabled, bool visible)
      {
         ItemClass = itemClass;
         Enabled = enabled;
         Visible = visible;
      }
   }

   public abstract class PriorityHandling<C, I> : List<ClassState<C>> where C : struct
   {
      private bool _HashDirty = true;
      private List<string> _ClassList = new List<string>();
      private Dictionary<C, int> _PrioHash = new Dictionary<C, int>();

      internal C? Selected { get; set; } //Visual

      internal PriorityHandling()
      {
         foreach (C itemClass in Enum.GetValues(typeof(C)))
         {
            Add(new ClassState<C>(itemClass, true, true));
         }
      }

      /// <summary>
      /// Retrieve the build/repair priority of the item.
      /// </summary>
      internal int GetPriority(I a)
      {
         var itemClass = GetItemClass(a, false);
         if (_HashDirty) UpdateHash();
         return _PrioHash[itemClass];
      }

      /// <summary>
      /// Retrieve if the build/repair of this item kind is enabled.
      /// </summary>
      internal bool GetEnabled(I a)
      {
         var itemClass = GetItemClass(a, true);
         if (_HashDirty) UpdateHash();
         return _PrioHash[itemClass] < int.MaxValue;
      }

      /// <summary>
      /// Retrieve if the build/repair of this item kind is enabled.
      /// </summary>
      internal bool GetEnabled(C a)
      {
         if (_HashDirty) UpdateHash();
         return _PrioHash[a] < int.MaxValue;
      }

      /// <summary>
      /// Get the item class
      /// </summary>
      /// <param name="a"></param>
      /// <returns></returns>
      public abstract C GetItemClass(I a, bool real);

      /// <summary>
      /// 
      /// </summary>
      /// <param name="items"></param>
      internal void FillTerminalList(List<MyTerminalControlListBoxItem> items, List<MyTerminalControlListBoxItem> selected)
      {
         foreach (var entry in this)
         {
            if (entry.Visible) {
               var item = new MyTerminalControlListBoxItem(MyStringId.GetOrCompute(string.Format("({0}) {1}", entry.Enabled ? "X" : "-", entry.ItemClass.ToString())), MyStringId.NullOrEmpty, entry.ItemClass);
               items.Add(item);

               if (entry.ItemClass.Equals(Selected))
               {
                  selected.Add(item);
               }
            }
         }
      }

      internal void MoveSelectedUp()
      {
         if (Selected != null)
         {
            var currentPrio = FindIndex((kv) => kv.ItemClass.Equals(Selected));
            if (currentPrio > 0)
            {
               this.Move(currentPrio, currentPrio - 1);
               _HashDirty = true;
            }
         }
      }

      internal void MoveSelectedDown()
      {
         if (Selected != null)
         {
            var currentPrio = FindIndex((kv) => kv.ItemClass.Equals(Selected));
            if (currentPrio >= 0 && currentPrio < Count - 1)
            {
               this.Move(currentPrio, currentPrio + 1);
               _HashDirty = true;
            }
         }
      }

      internal void ToggleEnabled()
      {
         if (Selected != null)
         {
            var keyValue = this.FirstOrDefault((kv) => kv.ItemClass.Equals(Selected));
            if (keyValue != null)
            {
               keyValue.Enabled = !keyValue.Enabled;
               _HashDirty = true;
            }
         }
      }

      internal int GetPriority(int itemClass)
      {
         return FindIndex((kv) => Convert.ToInt32(kv.ItemClass) == itemClass);
      }

      internal void SetPriority(int itemClass, int prio)
      {
         if (prio >= 0 && prio < Count)
         {
            var currentPrio = FindIndex((kv) => Convert.ToInt32(kv.ItemClass) == itemClass);
            if (currentPrio >= 0)
            {
               this.Move(currentPrio, prio);
               _HashDirty = true;
            }
         }
      }

      internal bool GetEnabled(int itemClass)
      {
         var keyValue = this.FirstOrDefault((kv) => Convert.ToInt32(kv.ItemClass) == itemClass);
         return keyValue != null ? keyValue.Enabled : false;
      }

      internal void SetEnabled(int itemClass, bool enabled)
      {
         var keyValue = this.FirstOrDefault((kv) => Convert.ToInt32(kv.ItemClass) == itemClass);
         if (keyValue != null)
         {
            if (keyValue.Enabled != enabled)
            {
               keyValue.Enabled = enabled;
               _HashDirty = true;
            }
         }
      }

      public bool AnyEnabled
      {
         get
         {
            return this.Any(i => i.Enabled);
         }
      }

      internal string GetEntries()
      {
         var value = string.Empty;
         foreach (var entry in this)
         {
            value += string.Format("{0};{1}|", Convert.ToInt32(entry.ItemClass), entry.Enabled);
         }
         return value.Remove(value.Length - 1);
      }

      internal void SetEntries(string value)
      {
         if (value == null) return;
         var entries = value.Split('|');
         var prio = 0;
         foreach (var val in entries)
         {
            var itemClassValue = 0;
            var enabled = true;
            var values = val.Split(';');
            if (values.Length >= 2 &&
               int.TryParse(values[0], out itemClassValue) &&
               bool.TryParse(values[1], out enabled))
            {
               var keyValue = this.FirstOrDefault((kv) => Convert.ToInt32(kv.ItemClass) == itemClassValue);
               if (keyValue != null)
               {
                  keyValue.Enabled = enabled;
                  var currentPrio = IndexOf(keyValue);
                  this.Move(currentPrio, prio);
                  prio++;
               }
            }
         }
         _HashDirty = true;
      }

      internal List<string> GetList()
      {
         if (_HashDirty) UpdateHash();
         return _ClassList;
      }

      public void UpdateHash()
      {
         lock (_ClassList)
         {
            if (_HashDirty) //Second check now thread safe
            {
               _ClassList.Clear();
               foreach (var item in this)
               {
                  _ClassList.Add(string.Format("{0};{1}", item.ItemClass, item.Enabled));
               }
               _PrioHash.Clear();
               var prio = 1;
               foreach (var item in this)
               {
                  _PrioHash.Add(item.ItemClass, item.Enabled ? prio : int.MaxValue);
                  prio++;
               }
               _HashDirty = false;
            }
         }
      }
   }
}
